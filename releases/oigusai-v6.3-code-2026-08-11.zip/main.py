"""
ÕigusAI v0.6.3 - Offline Legal Analysis System
Põhimõte: NO SOURCE -> NO LEGAL CLAIM
"""
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import List, Optional

from fastapi import Depends, FastAPI, HTTPException
from fastapi.concurrency import run_in_threadpool
from fastapi.requests import Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
import uvicorn

from config import load_settings
from services.case_intake import CaseIntakeService, MAX_INPUT_CHARS
from services.legal_search import (
    HistoricalDataUnavailableError,
    LegalDataUnavailableError,
    LegalSearchService,
    QueryUnderstandingUnavailableError,
)
from services.offline_ai import OfflineAIService
from services.turn_planner import ConversationTurnPlanner
from verifiers.relevance_verifier import RelevanceVerifier
from verifiers.source_verifier import SourceVerifier

settings = load_settings()
logging.basicConfig(level=getattr(logging, settings.log_level))
logger = logging.getLogger(__name__)
relevance_verifier = RelevanceVerifier()

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Initialize services once without making application import depend on legal-data availability."""
    app.state.legal_service = None
    app.state.legal_service_error = None

    try:
        app.state.legal_service = LegalSearchService(
            use_riigi_teataja=settings.allow_live_rt_fallback,
            data_file=settings.legal_data_file,
        )
        logger.info("Legal corpus initialized with %d sections", len(app.state.legal_service.laws))
    except (LegalDataUnavailableError, QueryUnderstandingUnavailableError) as exc:
        app.state.legal_service_error = str(exc)
        logger.error("Legal corpus unavailable: %s", exc)

    # OfflineAIService loeb sama keskse config.py ise. Konstruktorisse ei
    # süstita Settings objekti, et vältida tugevat versioonisõltuvust main.py
    # ja teenuse vahel.
    app.state.ai_service = OfflineAIService()

    required_ai_config = (
        "temperature",
        "top_p",
        "num_ctx",
        "num_predict",
        "think",
        "keep_alive",
        "citation_retries",
    )
    missing_ai_config = [
        name for name in required_ai_config if not hasattr(app.state.ai_service, name)
    ]
    if missing_ai_config:
        raise RuntimeError(
            "ÕigusAI failid on eri versioonidest: services/offline_ai.py on liiga vana "
            "v0.6.3 konfiguratsiooni jaoks. Puuduvad väljad: "
            + ", ".join(missing_ai_config)
            + ". Asenda kogu services/ kaust v0.6.3 paketist."
        )
    app.state.intake_service = CaseIntakeService(app.state.ai_service)
    app.state.verifier = SourceVerifier()
    yield


app = FastAPI(
    title="ÕigusAI v0.6.3",
    description="Kasutajasõbralik Eesti õiguse lokaalne analüüs kontrollitud viidetega",
    lifespan=lifespan,
)


class LawReference(BaseModel):
    id: str
    title: str
    source: str


class CaseAnalysisRequest(BaseModel):
    case_description: str = Field(min_length=1, max_length=MAX_INPUT_CHARS)
    event_date: Optional[str] = None
    search_query: Optional[str] = Field(default=None, max_length=2000)
    case_context: Optional[str] = Field(default=None, max_length=6000)
    current_message: Optional[str] = Field(default=None, max_length=10_000)
    answer_requirements: List[str] = Field(default_factory=list)


class CaseIntakeRequest(BaseModel):
    case_description: str = Field(min_length=1, max_length=MAX_INPUT_CHARS)
    event_date: Optional[str] = None
    current_message: Optional[str] = Field(default=None, max_length=10_000)


class IntakePartyResponse(BaseModel):
    role: str = ""
    label: str = ""
    evidence: str = ""


class IntakeEventResponse(BaseModel):
    date: str = ""
    actor: str = ""
    action: str = ""
    evidence: str = ""


class IntakeAmountResponse(BaseModel):
    label: str = ""
    value: str = ""
    evidence: str = ""


class IntakeDocumentResponse(BaseModel):
    name: str = ""
    evidence: str = ""


class CaseIntakeResponse(BaseModel):
    input_type: str
    topic: str
    summary: str
    user_goal: str
    help_types: List[str] = Field(default_factory=list)
    parties: List[IntakePartyResponse] = Field(default_factory=list)
    events: List[IntakeEventResponse] = Field(default_factory=list)
    amounts: List[IntakeAmountResponse] = Field(default_factory=list)
    documents: List[IntakeDocumentResponse] = Field(default_factory=list)
    missing_facts: List[str] = Field(default_factory=list)
    clarification_questions: List[str] = Field(default_factory=list)
    ready_for_analysis: bool
    search_query: str
    analysis_context: str
    input_length: int
    used_ai: bool
    current_intents: List[str] = Field(default_factory=list)
    next_action: str = "analyze"
    decision_reason: str = ""
    answer_requirements: List[str] = Field(default_factory=list)
    turn_summary: str = ""


class QueryMatchResponse(BaseModel):
    original: str
    candidate: str
    score: float
    domains: List[str] = Field(default_factory=list)
    reason: str


class QueryInterpretationResponse(BaseModel):
    expanded_tokens: List[str] = Field(default_factory=list)
    domain_hints: List[str] = Field(default_factory=list)
    section_hints: List[str] = Field(default_factory=list)
    matches: List[QueryMatchResponse] = Field(default_factory=list)
    notes: List[str] = Field(default_factory=list)


class CaseAnalysisResponse(BaseModel):
    analysis: str
    sources_used: List[str]
    verification_status: str
    is_mock: bool
    warning: Optional[str] = None
    found_laws: List[LawReference] = Field(default_factory=list)
    query_interpretation: Optional[QueryInterpretationResponse] = None


def get_legal_service(request: Request) -> LegalSearchService:
    service = getattr(request.app.state, "legal_service", None)
    if service is None:
        detail = getattr(request.app.state, "legal_service_error", None) or (
            "Õigusandmete korpus ei ole saadaval. Käivita esmalt Riigi Teataja importer."
        )
        raise HTTPException(status_code=503, detail=detail)
    return service


def get_ai_service(request: Request) -> OfflineAIService:
    return request.app.state.ai_service


def get_verifier(request: Request) -> SourceVerifier:
    return request.app.state.verifier


def get_intake_service(request: Request) -> CaseIntakeService:
    return request.app.state.intake_service


@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse(
        request,
        "chat.html",
        {"request": request},
        headers={
            "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
            "Pragma": "no-cache",
        },
    )


@app.get("/health")
async def health(request: Request):
    """Report trusted-corpus readiness and the optional V6 dense-search state."""
    legal_service = getattr(request.app.state, "legal_service", None)
    hybrid_status = (
        legal_service.hybrid_status()
        if legal_service is not None
        else {
            "enabled": settings.hybrid_retrieval_enabled,
            "ready": False,
            "embedding_model": settings.embedding_model,
            "embedding_dimension": 0,
            "vector_rows": 0,
            "error": "Õiguskorpus ei ole valmis.",
        }
    )
    reranker_status = (
        legal_service.reranker_status()
        if legal_service is not None
        else {
            "enabled": settings.reranker_enabled,
            "loaded": False,
            "ready": False,
            "model": settings.reranker_model,
            "device": settings.reranker_device,
            "candidates": settings.reranker_candidates,
            "error": "Õiguskorpus ei ole valmis.",
        }
    )
    return {
        "status": "ok" if legal_service is not None else "degraded",
        "legal_corpus_ready": legal_service is not None,
        "legal_sections": len(legal_service.laws) if legal_service is not None else 0,
        "query_understanding_ready": bool(
            legal_service is not None
            and getattr(legal_service, "query_understanding", None)
            and legal_service.query_understanding.enabled
        ),
        "query_vocabulary_terms": (
            legal_service.query_understanding.vocabulary_size
            if legal_service is not None and getattr(legal_service, "query_understanding", None)
            else 0
        ),
        "case_intake_ready": getattr(request.app.state, "intake_service", None) is not None,
        "hybrid_enabled": hybrid_status["enabled"],
        "hybrid_ready": hybrid_status["ready"],
        "embedding_model": hybrid_status["embedding_model"],
        "embedding_dimension": hybrid_status["embedding_dimension"],
        "vector_rows": hybrid_status["vector_rows"],
        "hybrid_error": hybrid_status["error"],
        "reranker_enabled": reranker_status["enabled"],
        "reranker_loaded": reranker_status["loaded"],
        "reranker_ready": reranker_status["ready"],
        "reranker_model": reranker_status["model"],
        "reranker_device": reranker_status["device"],
        "reranker_candidates": reranker_status["candidates"],
        "reranker_error": reranker_status["error"],
        "legal_corpus_error": getattr(request.app.state, "legal_service_error", None),
    }


@app.post("/intake", response_model=CaseIntakeResponse)
async def understand_case(
    request: CaseIntakeRequest,
    intake_service: CaseIntakeService = Depends(get_intake_service),
):
    try:
        result = await run_in_threadpool(
            intake_service.understand,
            request.case_description,
            request.event_date or "",
            request.current_message or "",
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return CaseIntakeResponse(**result)


@app.post("/analyze", response_model=CaseAnalysisResponse)
async def analyze_case(
    request: CaseAnalysisRequest,
    legal_service: LegalSearchService = Depends(get_legal_service),
    ai_service: OfflineAIService = Depends(get_ai_service),
    verifier: SourceVerifier = Depends(get_verifier),
):
    if not request.case_description or not request.case_description.strip():
        raise HTTPException(status_code=400, detail="Olukorra kirjeldus ei tohi olla tühi.")

    current_turn = (request.current_message or "").strip()
    answer_requirements = [
        str(value).strip()
        for value in request.answer_requirements
        if str(value).strip()
    ][:5]
    # A short clarification answer such as "Ma ei tea" is not the legal
    # question itself.  The intake layer has already preserved that question as
    # answer requirements, so use both inputs for routing and final coverage.
    intent_focus = "\n".join([current_turn, *answer_requirements]).strip()
    current_intents = ConversationTurnPlanner.detect_intents(intent_focus)
    fine_context = ConversationTurnPlanner.is_fine_context(request.case_description)

    try:
        search_text = (request.search_query or request.case_description).strip()
        laws, query_interpretation = legal_service.search_laws_with_context(
            search_text, request.event_date or ""
        )
    except HistoricalDataUnavailableError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    if not laws:
        raise HTTPException(
            status_code=404,
            detail=(
                "Ma ei leidnud veel piisavalt täpset õigusallikat. Lisa palun, "
                "kes tegi mida, millal see juhtus ja millist abi vajad."
            ),
        )

    query_context = query_interpretation.to_dict()
    hinted_id_list = [
        str(value).upper() for value in query_context.get("section_hints", [])
    ]
    hinted_ids = set(hinted_id_list)
    analysis_laws = laws
    if hinted_ids:
        # Section hints activate only on exact, audited lexicon phrases. When
        # such a hint exists, pass only those exact audited sections to the
        # model. A domain-level filter is too broad: adjacent sections in the
        # same act can be genuine sources yet completely unrelated to the case.
        available_by_id = {
            str(law.get("id", "")).upper(): law for law in laws
        }
        hinted_laws = []
        for section_id in hinted_id_list[:16]:
            law = available_by_id.get(section_id)
            if law is None and isinstance(legal_service, LegalSearchService):
                try:
                    law = legal_service.get_law_by_id(section_id)
                except ValueError:
                    law = None
            if law is not None:
                hinted_laws.append(law)
        if hinted_laws:
            analysis_laws = hinted_laws

    # A trahviteade, a lühimenetluse decision and a kiirmenetluse decision
    # have different contents and challenge routes. Once the user names the
    # document, keep only that document type's audited VTMS sections together
    # with the actor/rights sections; never blend their deadlines.
    normalized_route_context = (
        f"{request.case_description}\n{search_text}"
    ).casefold()
    document_routes = []
    is_explicit_warning_notice = (
        "hoiatustrahv" in normalized_route_context
        or "kirjalik hoiatamismenetlus" in normalized_route_context
        or (
            "mootorsõiduk" in normalized_route_context
            and "trahvitea" in normalized_route_context
        )
    )
    if is_explicit_warning_notice:
        document_routes = [
            "ABIPOLS_3", "ABIPOLS_16", "VTMS_19", "VTMS_54B2", "VTMS_54B5"
        ]
    elif "lühimenetluse otsus" in normalized_route_context or "mõjutustrahv" in normalized_route_context:
        document_routes = [
            "ABIPOLS_3", "ABIPOLS_16", "VTMS_19", "VTMS_54B9", "VTMS_54B11"
        ]
    elif "kiirmenetluse otsus" in normalized_route_context:
        document_routes = [
            "ABIPOLS_3", "ABIPOLS_16", "VTMS_19", "VTMS_57", "VTMS_114"
        ]

    # V6.3 routes the latest request independently from the historical document
    # wording.  One turn may require several source groups; never let a generic
    # old word such as "trahviteade" suppress deadline or payment-plan sources.
    intent_routes = []
    if fine_context and "missed_deadline" in current_intents:
        intent_routes.extend(["VTMS_114", "VTMS_118"])
    elif fine_context and "challenge_decision" in current_intents:
        intent_routes.extend(["VTMS_19", "VTMS_114"])
    if fine_context and "payment_plan" in current_intents:
        intent_routes.extend(["KARS_66", "VTMS_57", "VTMS_74", "VTMS_204"])

    routed_ids = list(dict.fromkeys([*document_routes, *intent_routes]))
    if routed_ids:
        routed_by_id = {
            str(law.get("id", "")).upper(): law for law in analysis_laws
        }
        routed_laws = []
        for section_id in routed_ids:
            law = routed_by_id.get(section_id)
            if law is None and isinstance(legal_service, LegalSearchService):
                try:
                    law = legal_service.get_law_by_id(section_id)
                except ValueError:
                    law = None
            if law is not None:
                routed_laws.append(law)
        if routed_laws:
            analysis_laws = routed_laws

    relevance_text = intent_focus or search_text
    if fine_context and not ConversationTurnPlanner.is_fine_context(relevance_text):
        relevance_text = f"rahatrahv {relevance_text}".strip()
    source_relevance = relevance_verifier.verify_laws(relevance_text, analysis_laws)
    if not source_relevance.relevant:
        logger.warning(
            "Retrieved laws failed semantic relevance check for concepts: %s",
            ", ".join(source_relevance.missing_concepts),
        )
        raise HTTPException(
            status_code=422,
            detail=source_relevance.clarification
            or relevance_verifier.clarification_for(source_relevance),
        )

    fallback_used = False
    # The structured intake summary may deliberately omit a legally decisive
    # word (for example "abipolitsei"). Keep the original account for ordinary
    # inputs and use the compact summary only to make very long inputs fit.
    analysis_case = CaseIntakeService._user_evidence_text(
        request.case_description
    ) or request.case_description.strip()
    if (
        len(analysis_case) > 8000
        and request.case_context
        and request.case_context.strip()
    ):
        analysis_case = (
            f"Kasutaja algteksti algus:\n{analysis_case[:4000]}\n\n"
            f"Kontrollitud juhtumikokkuvõte:\n"
            f"{request.case_context.strip()}"
        )
    if current_turn:
        requirement_text = "\n".join(
            f"- {value}" for value in answer_requirements
        )
        analysis_case += (
            f"\n\nKASUTAJA VIIMANE SÕNUM:\n{current_turn}\n\n"
            "Kasuta viimast sõnumit koos alltoodud vastusekohustustega. "
            "Varasem tekst on ainult taust."
        )
        if requirement_text:
            analysis_case += f"\nVASTUS PEAB KÄSITLEMA:\n{requirement_text}"
    try:
        analysis_text, is_mock = await run_in_threadpool(
            ai_service.analyze_case,
            analysis_case,
            analysis_laws,
            request.event_date or "",
        )
    except Exception as exc:
        logger.error("AI analysis unavailable; returning verified source digest: %s", exc)
        analysis_text = ai_service.build_source_only_fallback(
            analysis_case, analysis_laws
        )
        is_mock = False
        fallback_used = True

    is_valid, verified_sources = verifier.verify_sources(analysis_text, analysis_laws)

    if not is_valid and not fallback_used:
        logger.warning(
            "AI response failed citation verification; returning verified source digest"
        )
        analysis_text = ai_service.build_source_only_fallback(
            analysis_case, analysis_laws
        )
        is_valid, verified_sources = verifier.verify_sources(analysis_text, analysis_laws)
        fallback_used = True

    if not is_valid:
        logger.error("Deterministic source digest failed citation verification")
        raise HTTPException(status_code=500, detail="Kontrollitud allikate kuvamine ebaõnnestus.")

    cited_ids = set(verified_sources)
    cited_laws = [
        law for law in analysis_laws
        if str(law.get("id", "")).upper() in cited_ids
    ]
    answer_relevance = relevance_verifier.verify_answer(
        relevance_text, analysis_text, cited_laws
    )
    if not answer_relevance.relevant and not fallback_used:
        logger.warning(
            "AI response failed semantic relevance check; returning verified source digest"
        )
        analysis_text = ai_service.build_source_only_fallback(
            analysis_case, analysis_laws
        )
        is_valid, verified_sources = verifier.verify_sources(
            analysis_text, analysis_laws
        )
        fallback_used = True
        cited_ids = set(verified_sources)
        cited_laws = [
            law for law in analysis_laws
            if str(law.get("id", "")).upper() in cited_ids
        ]
        answer_relevance = relevance_verifier.verify_answer(
            relevance_text, analysis_text, cited_laws
        )

    if not is_valid:
        logger.error("Relevance fallback failed citation verification")
        raise HTTPException(
            status_code=500,
            detail="Kontrollitud allikate kuvamine ebaõnnestus.",
        )

    if not answer_relevance.relevant:
        logger.warning(
            "Final answer failed semantic relevance check for concepts: %s",
            ", ".join(answer_relevance.missing_concepts),
        )
        raise HTTPException(
            status_code=422,
            detail=answer_relevance.clarification
            or relevance_verifier.clarification_for(answer_relevance),
        )

    warning = (
        "Viidete ID-d ja mudeli valitud tõendikatkendid on kontrollitud etteantud "
        "õigusallikate vastu, kuid see ei tõenda automaatselt iga järelduse materiaalset "
        "õigsust. Tegemist on esmase analüüsiga, mitte õigusnõuga."
    )
    if is_mock:
        warning = "TESTREŽIIM: Ollama vastus on näidisvastus. " + warning
    if fallback_used:
        warning = (
            "Selgitus põhineb kontrollitud õigusallikatel. Täpsema vastuse saab anda "
            "dokumendi pealkirja ja sellele märgitud rikkumise põhjal."
        )

    return CaseAnalysisResponse(
        analysis=analysis_text,
        sources_used=verified_sources,
        verification_status=(
            "SOURCE_ONLY_FALLBACK" if fallback_used else "CITATIONS_VERIFIED"
        ),
        is_mock=is_mock,
        warning=warning,
        found_laws=[
            LawReference(id=law["id"], title=law["title"], source=law["source"])
            for law in analysis_laws
        ],
        query_interpretation=QueryInterpretationResponse(**query_context),
    )


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=settings.app_host,
        port=settings.app_port,
        reload=settings.app_reload,
        log_level=settings.log_level.lower(),
    )
