"""Ephemeral local matters for V8 document-aware conversations."""

from __future__ import annotations

import re
import threading
import uuid
from datetime import datetime, timezone
from typing import Dict, Iterable, List, Optional


class MatterNotFoundError(KeyError):
    pass


class MatterStore:
    """Thread-safe in-memory registry; raw uploaded files are never persisted."""

    def __init__(self, max_matters: int = 100, max_documents_per_matter: int = 20):
        self.max_matters = max_matters
        self.max_documents_per_matter = max_documents_per_matter
        self._matters: Dict[str, Dict] = {}
        self._lock = threading.RLock()

    def create(self, title: str = "Uus juhtum") -> Dict:
        with self._lock:
            if len(self._matters) >= self.max_matters:
                oldest = min(
                    self._matters.values(),
                    key=lambda item: item["updated_at"],
                )
                self._matters.pop(oldest["matter_id"], None)
            now = datetime.now(timezone.utc).isoformat()
            matter = {
                "matter_id": str(uuid.uuid4()),
                "title": str(title or "Uus juhtum").strip()[:120],
                "created_at": now,
                "updated_at": now,
                "documents": {},
            }
            self._matters[matter["matter_id"]] = matter
            return self._public(matter)

    def add_document(self, matter_id: Optional[str], document: Dict) -> Dict:
        with self._lock:
            if not matter_id:
                matter_id = self.create()["matter_id"]
            matter = self._matters.get(matter_id)
            if matter is None:
                raise MatterNotFoundError(matter_id)
            is_new = document["document_id"] not in matter["documents"]
            if is_new and len(matter["documents"]) >= self.max_documents_per_matter:
                raise ValueError("Ühes juhtumis võib olla kuni 20 dokumenti.")
            matter["documents"][document["document_id"]] = document
            matter["updated_at"] = datetime.now(timezone.utc).isoformat()
            return {"matter": self._public(matter), "document": self._document_public(document)}

    def get(self, matter_id: str) -> Dict:
        with self._lock:
            matter = self._matters.get(matter_id)
            if matter is None:
                raise MatterNotFoundError(matter_id)
            return self._public(matter)

    def delete(self, matter_id: str) -> bool:
        with self._lock:
            return self._matters.pop(matter_id, None) is not None

    def relevant_spans(
        self,
        matter_id: str,
        document_ids: Iterable[str],
        query: str,
        limit: int = 8,
    ) -> List[Dict]:
        with self._lock:
            matter = self._matters.get(matter_id)
            if matter is None:
                raise MatterNotFoundError(matter_id)
            allowed = set(document_ids or matter["documents"].keys())
            spans = [
                span.copy()
                for document_id, document in matter["documents"].items()
                if document_id in allowed
                for span in document.get("spans", [])
            ]
        query_terms = set(re.findall(r"[a-zõäöü]{4,}", str(query or "").casefold()))
        scored = []
        for index, span in enumerate(spans):
            terms = set(re.findall(r"[a-zõäöü]{4,}", span["text"].casefold()))
            overlap = len(query_terms.intersection(terms))
            score = overlap * 10 - min(index, 20) * 0.01
            scored.append((score, index, span))
        scored.sort(key=lambda item: (-item[0], item[1]))
        selected = [item[2] for item in scored[:limit]]
        return selected

    @staticmethod
    def _document_public(document: Dict) -> Dict:
        return {
            key: value
            for key, value in document.items()
            if key != "spans"
        } | {"span_count": len(document.get("spans", []))}

    @classmethod
    def _public(cls, matter: Dict) -> Dict:
        return {
            "matter_id": matter["matter_id"],
            "title": matter["title"],
            "created_at": matter["created_at"],
            "updated_at": matter["updated_at"],
            "documents": [
                cls._document_public(document)
                for document in matter["documents"].values()
            ],
        }
