# ÕigusAI V6.3 – viimase sõnumi mõistmine

Kuupäev: 11.08.2026

## Eesmärk

ÕigusAI peab käsitlema vestlust tervikuna, kuid tegema järgmise otsuse kasutaja
viimase sõnumi põhjal. Varasemad sõnumid annavad tausta ega tohi uut küsimust
valesse õigusvaldkonda tagasi tõmmata.

## Otsustusvoog

1. Kasutajaliides saadab eraldi nii kogu senise juhtumikirjelduse kui ka viimase
   kasutajasõnumi.
2. Vastuvõtukiht tuvastab viimases sõnumis kõik eesmärgid, mitte ainult ühe.
3. Planeerija otsustab, kas olemasoleva info põhjal saab kohe analüüsida või on
   vaja üht otsustavat täpsustust.
4. Kui mitu asjaolu on puudu, koondatakse need üheks kasutajasõbralikuks
   küsimuseks.
5. Otsing koostab viimase sõnumi eesmärkidest eraldi kohustused ja valib iga
   alamküsimuse jaoks allikad.
6. Vastuse kontroll lükkab tulemuse tagasi, kui mõni kasutaja alamküsimus jäi
   käsitlemata.

## Praegu toetatud keeruline trahvivoog

Ühes viimases sõnumis võivad korraga esineda:

- möödunud kaebetähtaeg;
- otsuse vaidlustamise soov;
- rahatrahvi osade kaupa tasumise soov;
- summa ja täitemenetluse olukord.

Sellises olukorras ei sunnita üldist väljendit „trahviteade” automaatselt
mootorsõiduki kirjaliku hoiatamismenetluse rajale. Süsteem küsib vajaduse korral
dokumendi täpset pealkirja, kättesaamise aega, täitmise seisu ja kinnitab
ebatavaliselt suure summa. Kui kasutaja vastab „Ma ei tea”, sama küsimust enam ei
korrata ning vastus koostatakse tingimuslikult teadaoleva info põhjal.

## Ohutus

- Mudeli vastus ei või asendada kasutaja viimast küsimust varasema teemaga.
- Iga tuvastatud eesmärk peab olema vastuses või kontrollitud varuvastuses
  käsitletud.
- Seaduseväited kuvatakse ainult kontrollitud allikatega.
- Puuduva dokumendiliigi või kuupäeva korral ei esitata menetlust ega tähtaega
  kindla faktina.

## Kontroll

Muudatust katavad planeerija-, vastuvõtu-, otsingu-, viitekontrolli-, varuvastuse-
ja API-testid. Kogu projekti testikomplektis on 111 testi.
